from tkinter import *

window = Tk()
window.geometry("400x500")
window.title("Admin")
window.configure(background="teal")


window.mainloop()

